<?php
  @session_start();
  include "../koneksi.php";
  if (@$_SESSION['admin']) {
    
?>

<!DOCTYPE html>
<html lang="id">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="../../assets/ico/favicon.ico">

    <title>ADMIN || NanCod{}</title>

    <!-- Bootstrap core CSS -->
    <link href="../dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../dist/css/dashboard.css" rel="stylesheet">

    <link href="../dist/css/sticky-footer.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand">ADMIN POLIKLINIK</a>
        </div>
        <div class="navbar-collapse collapse" id="bs-example-navbar-collapse-1">
          <ul class="nav navbar-nav navbar-right">
          <div class="btn-group">
              <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                <span class="glyphicon glyphicon-user"></span> <?php echo ($_SESSION['admin']) ?>
                <span class="caret"></span>
              </button>
              <ul class="dropdown-menu">
                <li><a href="../inc/logout.php"><span class="glyphicon glyphicon-off"></span> Logout</a></li>
              </ul>
            </div>
            <li><a href="index.php"><span class="glyphicon glyphicon-dashboard"></span> Dashboard</a></li>
          </ul>
        </div>
      </div>
    </div>

    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
            <li class="active"><a href="#"><span class="glyphicon glyphicon-dashboard"></span> DASHBOARD</a></li>
            <li><a href="?page=pegawai_view"><span class="glyphicon glyphicon-user"></span>  Data Pegawai</a></li>
            <li><a href="?page=dokter_view"><span class="glyphicon glyphicon-user"></span> Data Dokter</a></li>
            <li><a href="?page=jadwal_view"><span class="glyphicon glyphicon-calendar"></span> Data Jadwal Praktek</a></li>
            <li><a href="?page=poli_view"><span class="glyphicon glyphicon-heart-empty"></span> Data Poliklinik</a></li>
            <li><a href="?page=obat_view"><span class="glyphicon glyphicon-plus"></span> Data Obat</a></li>
            <li><a href="?page=jenis_biaya_view"><span class="glyphicon glyphicon-usd"></span> Data Jenis Biaya</a></li>
            <li><a href="?page=backup_data"><span class="glyphicon glyphicon-save"></span> Backup Data</a></li>
          </ul>
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          <h1 class="page-header"><span class="glyphicon glyphicon-dashboard"></span> Dashboard </h1>
        </div>
      </div>
    </div>
    <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
    <div class="table-responsive">
            <table class="table table-striped">
                <?php 
                    switch (@$_GET['page']) {
                      case 'pegawai_view': include("../model/pegawai/pegawai.php");break;
                      case 'pegawai_delete': include("../model/pegawai/pegawai_delete.php");break;
                      case 'pegawai_create': include("../model/pegawai/pegawai_create.php");break;
                      case 'pegawai_edit': include("../model/pegawai/pegawai_edit.php");break;
                      case 'hak_akses_peg': include("../model/pegawai/hak_akses_peg.php");break;
                      case 'delete_hak_akses_peg': include("../model/pegawai/delete_hak_akses.php");break;
                      case 'report_peg': include("../model/pegawai/report_peg.php");break;
                      case 'report_peg_pdf': include("../model/report/carireport.php");break;
                      case 'hak_akses_report': include("../model/pegawai/hak_akses_report.php");break;
                             case 'poli_view': include("../model/poli/poli.php");break;
                             case 'poli_create': include("../model/poli/poli_create.php");break;
                             case 'poli_edit': include("../model/poli/poli_edit.php");break;
                             case 'poli_delete': include("../model/poli/poli_delete.php");break;
                        case 'jadwal_view': include("../model/jadwal/jadwal.php");break;
                        case 'jadwal_create': include("../model/jadwal/jadwal_create.php");break;
                        case 'jadwal_delete': include("../model/jadwal/jadwal_delete.php");break;
                        case 'jadwal_edit': include("../model/jadwal/jadwal_edit.php");break;
                        case 'cek_up': include("../model/jadwal/jadwal_cek_up.php");break;
                    case 'dokter_view': include("../model/dokter/dokter.php");break;
                    case 'dokter_create': include("../model/dokter/dokter_create.php");break;
                    case 'dokter_delete': include("../model/dokter/dokter_delete.php");break;
                    case 'jadwal_dokter': include("../model/dokter/dokter_jadwal.php");break;
                    case 'data_dokter_report': include("../model/dokter/data_dokter_report.php");break;
                    case 'jadwal_dokter_report': include("../model/dokter/report_dokter_jadwal.php");break;
                        case 'obat_view': include("../model/obat/obat.php");break;
                            case 'jenis_biaya_view': include("../model/jenis_biaya/jenis_biaya.php");break;
                        case 'backup_data': include("../model//backup/backupdb.php");break;
                                                   
                      }
                ?>
            </table>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="../dist/js/jquery.min.js"></script>
    <script src="../dist/js/bootstrap.min.js"></script>
    <script src="../assets/js/docs.min.js"></script>
  </body>
</html>

<?php 

  }else {
    header("Location: ../inc/login.php");
  }

?>