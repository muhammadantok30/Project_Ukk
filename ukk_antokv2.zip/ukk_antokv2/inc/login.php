<?php
@session_start();
 include ("../koneksi.php");
  if(@$_SESSION['admin']){
    header("Location: ../admin/index.php"); 
  }
  elseif (@$_SESSION['kasir']) {
    header("Location: ../kasir/index.php");
  }
  elseif (@$_SESSION['asisten']) {
    header("Location: ../dokter/index.php");
  }
  elseif (@$_SESSION['pendaftar']) {
    header("Location: ../pendaftar/index.php");
  }
  else{
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="../../assets/ico/favicon.ico">

    <title>Login Area</title>

    <!-- Bootstrap core CSS -->
    <link href="../dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../dist/css/signin.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <div class="container">
     <form class="form-signin" role="form" action="" method="post">
        <div class="panel panel-primary">
            <div class="panel-heading">
            <center>
            <img src="../images/me.jpg" width="90px" alt="" class="img-circle">
            <br>
              <h1 class="">LOGIN AREA</h1>
              <h4 class="panel-title">input you're acuratly personal data</h4>
            </center>
            </div>
            <br>
            <div class="panel-body">
              <input name="username" type="text" class="form-control" placeholder="Username"  autofocus>
              <br>
              <input name="password" type="password" class="form-control" placeholder="Password" >
              <br>
             <input type="submit" class="btn btn-lg btn-primary btn-block" value="login" name="login">
             </p>
             <a href="../index.php"><button type="button" class="btn btn-lg btn-danger btn-block">Cancel</button></a>
           </div>
           </div>

      </form>
    </div> <!-- /container -->
    <?php

      $user     = @$_POST['username'];
      $pass     = @$_POST['password'];
      $login    = @$_POST['login'];

      if ($login) {
        if ($user == "" || $pass == "") {
          echo "Username Kosong !!";
        }
        else {
          $sql = mysql_query("SELECT * FROM tb_login WHERE username = '$user' AND password = MD5('$pass') ")  or die ("MySql Error");
          $data = mysql_fetch_array($sql);
          $cek = mysql_num_rows($sql);
          if ($cek >= 1) {
            if($data['type_user'] == "admin"){
              @$_SESSION['admin'] = $data ['username'];
              header("Location: ../admin/index.php");
            }
            else if ($data ['type_user'] == "kasir") {
              @$_SESSION['kasir'] = $data ['username'];
              header("Location: ../kasir/index.php");
            }
            else if ($data ['type_user'] == "asisten") {
              @$_SESSION['asisten'] = $data ['username'];
              header("Location: ../dokter/index.php");
            }
            else if ($data ['type_user'] == "pendaftar") {
              @$_SESSION['pendaftar'] = $data ['username'];
              header("Location: ../pendaftar/index.php");
            }
          } else{
            echo("Login gagal");
          }
        }
      }

    ?>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
  </body>
</html>
<?php

  }

?>
