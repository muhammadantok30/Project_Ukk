<?php
    include"koneksi.php";
?>
<div class="container">
          
  				<table class="table table-hover">	
  				<thead>
    				<tr class="success">
    				<h5><b>
    					<th width="3%">No</th>
			        	<th>Kode Poli</th>
			        	<th>Jenis Poli</th>
			         </b></h5>
        			</tr>
        		</thead>
        		<tbody>
        		<?php
        		if (isset($_POST['btn_cari'])) {
        			$cari=$_POST['txcari'];
        			$no 		= 	1;
        			$sql=mysql_query("SELECT * from tb_poliklinik where kode_poli like '%$cari%' or nama_poli like '%$cari%'");
        		}else{
        			$no         =   1;
        			$sql=mysql_query("select * from tb_poliklinik ");
        		}
        		$ros=mysql_num_rows($sql);
        		$ris=mysql_num_fields($sql);
		            while ($row=mysql_fetch_array($sql, MYSQL_NUM)){
		            ?>
		            
		            <tr>
		              <td><span class="badge"><?php echo $no; ?></span></td>
		              <td><span class="label label-info"> <?php echo $row[0] ?></span></td>
		              <td><span class="label label-success"> <?php echo $row[1] ?></span></td>
		             
		         <?php
		         	$no ++;
		             }
		         ?>
		         </tbody>
                </table>
                </div>   
            </div>
            </div>  
        </div>