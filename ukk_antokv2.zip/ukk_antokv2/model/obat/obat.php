<?php
    include"../koneksi.php";
?>
<div class="container">
            <div class="row">
            <div class="col-lg-12">
            <h3 class="sub-header">Data Obat</h3>
            <p>
  				<a href="?page="><button type="button" class="btn btn-success"><span class="glyphicon glyphicon-plus"></span>Create</button></a>
  				<a href="?page="><button type="button" class="btn btn-info"><span class="glyphicon glyphicon-eye-open"></span> View All</button></a>
 				<form method="post" class="form-inline">
		  			
				  <div class="row">
				  <div class="col-lg-6">
				    <div class="input-group">
				      <input type="submit" value="Cari" name="btn_cari" class="btn btn-info">
				     <input type="text" class="form-control" placeholder="Masukkan Kode / Jenis Poli" name="txcari">
				    </div><!-- /input-group -->
				  </div><!-- /.col-lg-6 -->
				  </div><!-- /.col-lg-6 -->
  			</form>

  			</p>
  			<hr>
  			<div class="table table-responsive">
  				<table class="table table-hover">	
  				<thead>
    				<tr class="success">
    				<h5><b>
    					<th width="3%">No</th>
			        	<th>Kode Obat</th>
			        	<th>Nama Obat</th>
			        	<th>Merk</th>
			        	<th>Satuan</th>
			        	<th>Harga Jual</th>
			        	<th>Aksi</th>
			         </b></h5>
        			</tr>
        		</thead>
        		<tbody>
        		<?php
        		if (isset($_POST['btn_cari'])) {
        			$cari=$_POST['txcari'];
        			$no 		= 	1;
        			$sql=mysql_query("SELECT * from tb_obat where kode_obat like '%$cari%' or merk like '%$cari%'");
        		}else{
        			$no         =   1;
        			$sql=mysql_query("select * from tb_obat ");
        		}
        		$ros=mysql_num_rows($sql);
        		$ris=mysql_num_fields($sql);
		            while ($row=mysql_fetch_array($sql, MYSQL_NUM)){
		            ?>
		            
		            <tr>
		              <td><span class="badge"><?php echo $no; ?></span></td>
		              <td><?php echo $row[0] ?></td>
		              <td><?php echo $row[1] ?></td>
		              <td><?php echo $row[2] ?></td>
		              <td><?php echo $row[3] ?></td>
		              <td><?php echo $row[4] ?></td>

		              <td width="80">
		              	<a href="?page=&&delete=<?php echo $row[0] ?>" onclick="return confirm('apakah anda yakin mau menghapus data ini???')">
		              		<button type="button" class="btn btn-danger btn-xs"> 
		           			<span class="glyphicon glyphicon-trash"></span>
		              		</button>
		              	</a>
		              	<a href="?page=&&ubah=<?php echo $row[0] ?>">
		              		<button type="button" class="btn btn-primary btn-xs"> 
							<span class="glyphicon glyphicon-pencil"></span>
		              		</button>
		              	</a>	
		              </td>
		              
		         <?php
		         	$no ++;
		             }
		         ?>
		         </tbody>
                </table>
                </div>   
            </div>
            </div>  
        </div>