<div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="page-header">
                            Data Jadwal
                    </h2>
                </div>
            </div>
<div class="panel panel-info">
  <div class="panel-heading"><center>Ubah Data JAdwal</center></div>
      <div class="panel-body"> 
        <?php
            include"../koneksi.php";
        ?>
            <?php
                if (isset($_GET['ubah'])) {
                    $Kode=$_GET['ubah'];
                    $sql=mysql_query("select * from tb_jadwal_praktik where kode_jadwal='$Kode'");
                    $tampil=mysql_fetch_array($sql);
            ?> 
        <form method="post">           
            <label class="control-label for="inputSuccess4"">
                Kode Jadwal
            </label>
                <input type="text" class="form-control" name="kode_jadwal" value="<?php echo $tampil['0']?>" readonly>
            </p>
            <label class="control-label for="inputSuccess4"">
                Hari 
            </label>
                <input type="text" class="form-control" name="hari" value="<?php echo $tampil['1']?>">
            </p>
            <label class="control-label for="inputSuccess4"">
                Jam Mulai 
            </label>
                <input type="text" class="form-control" name="jam1" value="<?php echo $tampil['2']?>">
            </p>
                <label class="control-label for="inputSuccess4"">
                Jam Selesai 
            </label>
                <input type="text" class="form-control" name="jam2" value="<?php echo $tampil['3']?>">

            <label></label>
            </p>
             <input type="submit" name="edit" value="Edit" class=" btn btn-success">
            <a href="?page=jadwal_view"><button type="button" class="btn btn-warning">Cancel</button></a>
        </form>
         <?php
            }
            if (isset($_POST['edit'])) {
                $kode=$_POST['kode_jadwal'];
                $hari=$_POST['hari'];
                $jam1=$_POST['jam1'];
                $jam2=$_POST['jam2'];
                                
                $query=mysql_query("UPDATE tb_jadwal_praktik SET  kode_jadwal =  '$kode', hari =  '$hari', jam_mulai = '$jam1', jam_selesai = '$jam2' WHERE  kode_jadwal =  '$kode'");
                if($query){
                    echo'<script>alert("Data Berhasil Di Update");
                    window.location.assign("?page=jadwal_view");</script>';
                }else{
                    echo'<script>alert("Data Gagal Di Update");</script>';
                }
            }
            ?>
 </div>                                 
</div>