<?php
    include"../koneksi.php";
?>
<div class="container">
            <div class="row">
            <div class="col-lg-12">
            <h3 class="sub-header">Data Pegawai</h3>
            <p>
  				<a href="?page=pegawai_create"><button type="button" class="btn btn-success"><span class="glyphicon glyphicon-plus"></span> Create</button></a>
  				<a href="?page=pegawai_view"><button type="button" class="btn btn-info"><span class="glyphicon glyphicon-eye-open"></span> View All</button></a>
  				<a href="?page=hak_akses_report" target="_blank"><button type="button" class="btn btn-warning"><span class="glyphicon glyphicon-print"></span> Print</button></a>
 				
 			<form method="post" class="form-inline">
		  		<div class="row">
				  <div class="col-lg-6">
				    <div class="input-group">
				      <input type="submit" value="Cari" name="btn_cari" class="btn btn-info">
				     <input type="text" class="form-control" placeholder="Masukkan NIP / Nama" name="txcari">
				    </div><!-- /input-group -->
				  </div><!-- /.col-lg-6 -->
				  </div><!-- /.col-lg-6 -->
  			</form>

  			</p>
  			<hr>
  			<div class="table table-responsive">
  				<table class="table table-hover">	
  				<thead>
    				<tr class="success">
    				<h5><b>
    					<th width="3%">No</th>
			        	<th>NIP</th>
			        	<th>Nama Pegawai</th>
			        	<th>Alamat Pegawai</th>
			        	<th>Telepon Pegawai</th>
			        	<th>Jenis Kelamin</th>
			        	<th>Hak Akses</th>

			        	<th>Aksi</th>
			         </b></h5>
        			</tr>
        		</thead>
        		<tbody>
        		<?php
        		if (isset($_POST['btn_cari'])) {
        			$cari=$_POST['txcari'];
        			$no 		= 	1;
        			$sql=mysql_query("SELECT * from pegawai where nip like '%$cari%' or nama_peg like '%$cari%'");
        		}else{
        			$no         =   1;
        			$sql=mysql_query("SELECT * from pegawai ORDER BY nip ASC ");
        		}
        		$ros=mysql_num_rows($sql);
        		$ris=mysql_num_fields($sql);
		            while ($row=mysql_fetch_array($sql, MYSQL_NUM)){
		            ?>
		            
		            <tr>
		              <td><span class="badge"> <?php echo $no; ?></span></td>
		              <td><?php echo $row[0] ?></td>
		              <td><?php echo $row[1] ?></td>
		              <td><?php echo $row[2] ?></td>
		              <td><?php echo $row[3] ?></td>
		              <td><?php echo $row[4] ?></td>
		              <td><span class="label label-success"><?php echo $row[5] ?></span></td>

		              <td width="80">
		              	<a href="?page=delete_hak_akses_peg&&delete=<?php echo $row[0] ?>" onclick="return confirm('apakah anda yakin mau menghapus data ini???')">
		              		<button type="button" class="btn btn-danger btn-xs"> 
		           			<span class="glyphicon glyphicon-trash"></span>
		              		</button>
		              	</a>
		              	<a href="?page=&&ubah=<?php echo $row[0] ?>">
		              		<button type="button" class="btn btn-primary btn-xs"> 
							<span class="glyphicon glyphicon-pencil"></span>
		              		</button>
		              	</a>	
		              </td>
		              
		         <?php
		         	$no ++;
		             }
		         ?>
		         </tbody>
                </table>
                </div>   
            </div>
            </div>  
        </div>