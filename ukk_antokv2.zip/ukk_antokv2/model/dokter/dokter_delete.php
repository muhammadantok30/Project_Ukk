<?php
include"../koneksi.php";
?>
<?php
if (isset($_GET['delete'])) {
		$id			=	$_GET['delete'];

		$delete 	=	mysql_query("DELETE FROM tb_dokter WHERE kode_dok = '$id'");
		if ($delete) {
			echo "<meta http-equiv='refresh' content='0;URL= ?page=dokter_view'/>";
		}
	}
	?>