<?php
    include"../koneksi.php";
?>
<div class="container">
		<body onload="print">
  			<div class="table table-responsive">
  				<table class="table table-hover">	
  				<thead>
    				<tr class="success">
    				<h5><b>
    					<th width="3%">No</th>
    					<th>Nama Dokter</th>
			        	<th>Alamat Dokter</th>
			        	<th>Hari</th>
			        	<th>Jam Mulai</th>
			        	<th>Jam Selesai</th>
			        	
			         </b></h5>
        			</tr>
        		</thead>
        		<tbody>
        		<?php
        		if (isset($_POST['btn_cari'])) {
        			$cari=$_POST['txcari'];
        			$no 		= 	1;
        			$sql=mysql_query("SELECT * from jadwal where nama_dok like '%$cari%' or hari like '%$cari%'");
        		}else{
        			$no         =   1;
        			$sql=mysql_query("SELECT * from jadwal ");
        		}
        		$ros=mysql_num_rows($sql);
        		$ris=mysql_num_fields($sql);
		            while ($row=mysql_fetch_array($sql, MYSQL_NUM)){
		            ?>
		            
		            <tr>
		              <td><span class="badge"><?php echo $no; ?></span></td>
		              <td><?php echo $row[0] ?></td>
		              <td><?php echo $row[1] ?></td>
		              <td><span class="label label-info"><?php echo $row[2] ?></span></td>
		              <td><?php echo $row[3] ?></td>
		              <td><?php echo $row[4] ?></td>
		             
		         <?php
		         	$no ++;
		             }
		         ?>
		         </tbody>
                </table>
                </div>   
            </div>
            </div>  
        </div>
    </body>
<script type="text/javascript">
	window.print();
</script>