<?php
    include"../koneksi.php";
?>
<div class="container">
	<body onload="print">
            <div class="row">
            <div class="col-lg-12">
            <h3 class="sub-header">Data Dokter</h3>
	   		<div class="table table-responsive">
  				<table class="table table-hover">	
  				<thead>
    				<tr class="success">
    				<h5><b>
    					<th width="3%">No</th>
			        	<th>Kode Dokter</th>
			        	<th>Nama Dokter</th>
			        	<th>Alamat Dokter</th>
			        	<th>Telepon Dokter</th>
			        	<th>Kode Poli</th>
			        	<th>Kode Jadwal</th>
			        	
			         </b></h5>
        			</tr>
        		</thead>
        		<tbody>
        		<?php
        		if (isset($_POST['btn_cari'])) {
        			$cari=$_POST['txcari'];
        			$no 		= 	1;
        			$sql=mysql_query("SELECT * from tb_dokter where kode_dok like '%$cari%' or nama_dok like '%$cari%'");
        		}else{
        			$no         =   1;
        			$sql=mysql_query("SELECT * from tb_dokter ORDER BY kode_dok ASC ");
        		}
        		$ros=mysql_num_rows($sql);
        		$ris=mysql_num_fields($sql);
		            while ($row=mysql_fetch_array($sql, MYSQL_NUM)){
		            ?>
		            
		            <tr>
		              <td><span class="badge"><?php echo $no; ?></span></td>
		              <td><?php echo $row[0] ?></td>
		              <td><?php echo $row[1] ?></td>
		              <td><?php echo $row[2] ?></td>
		              <td><?php echo $row[3] ?></td>
		              <td><?php echo $row[4] ?></td>
		              <td><?php echo $row[5] ?></td>
		             
		         <?php
		         	$no ++;
		             }
		         ?>
		         </tbody>
                </table>
                </div>   
            </div>
            </div>  
        </div>
        </body>
<script type="text/javascript">
	window.print();
</script>