<form action="../model/report/report.php" method="POST" role="form">
	<legend>Form title</legend>
<div class="col-xs-3">
	<div class="form-group">
		<label for="">Dari</label>
		<input type="text" name="dari" class="form-control" placeholder="From">
	</div>
	
	<div class="form-group">
		<label for="">Sampai</label>
		<input type="text" name="sampai"  class="form-control" placeholder="To">
	</div>

	<button type="submit" name="print" class="btn btn-info"><span class="glyphicon glyphicon-print"></span> Print</button>
	</div>
</form>