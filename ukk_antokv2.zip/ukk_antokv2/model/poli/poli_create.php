<?php
include "../koneksi.php";
?>
<?php
  $query_oto = mysql_query("select max(kode_poli) as maks from tb_poliklinik");
  $data_oto = mysql_fetch_array($query_oto);
  $data_auto = substr($data_oto['maks'],4,6);
  $data_auto++;
  $koded="";
  for ($i=strlen($data_auto); $i <=5 ; $i++)
    $koded = $koded."0";
    $data['kode_poli'] = "POLI$koded$data_auto";

?>

    <?php
    if (isset($_POST['tambah'])) {
        $kode=$_POST['kode_poli'];
        $nama=$_POST['nama_poli'];
        
        if ($nama == "") {
          echo '<script>alert("Nama Poli tidak boleh kosong!!")</script';
        }
        else {
          $sql = mysql_query("INSERT INTO tb_poliklinik values ('$kode','$nama')");
         if($sql){
            echo'<script>alert("Data Berhasil Di Tambah");
                window.location.assign("?page=poli_view");</script>';
         }

        }
        
    }
    ?>

<div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="page-header">Create</h2>
                </div>
            </div>
<div class="panel panel-success">
  <div class="panel-heading"><center> Tambah Data Poli</center></div>
      <div class="panel-body"> 
      <form method="post">           
            <label class="control-label for="inputSuccess4"">
                Kode Poli
            </label>
                <input type="text" name="kode_poli" value="<?php echo $data['kode_poli'] ?>" class="form-control" readonly>   
            </p>
             <label class="control-label for="inputSuccess4"">
                Nama Poli
            </label>
                <input type="text" lenght-max="8-12" name="nama_poli" class="form-control" >   
            </p>
            <label></label>
            
            <input type="submit" name="tambah" value="Create" class=" btn btn-success">
            <a href="?page=poli_view"><button type="button" class="btn btn-warning">Cancel</button></a>
        </form>
    </div>
    </div>
</div>