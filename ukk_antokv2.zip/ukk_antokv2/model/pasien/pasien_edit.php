<div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="page-header">
                            Data Pasien
                    </h2>
                </div>
            </div>
<div class="panel panel-info">
  <div class="panel-heading"><center>Ubah Data Pasien</center></div>
      <div class="panel-body"> 
        <?php
            include"../koneksi.php";
        ?>
            <?php
                if (isset($_GET['ubah'])) {
                    $Kode=$_GET['ubah'];
                    $sql=mysql_query("select * from tb_pasien where kode_pas='$Kode'");
                    $tampil=mysql_fetch_array($sql);
            ?> 
        <form method="post">           
            <label class="control-label for="inputSuccess4"">
                NIP
            </label>
                <input type="text" class="form-control" value="<?php echo $tampil['0']?>" readonly>
                <input type="hidden" name="no" value="<?php echo $tampil['0']?>">   
            </p>
            <label class="control-label for="inputSuccess4"">
                Nama 
            </label>
                <input type="text" class="form-control" name="nama" value="<?php echo $tampil['1']?>">
            </p>
            <label class="control-label for="inputSuccess4"">
                Alamat 
            </label>
                <input type="text" class="form-control" name="alamat" value="<?php echo $tampil['2']?>">
            </p>
            <label class="control-label for="inputSuccess4"">
                Telepon 
            </label>
                <input type="text" class="form-control" name="telepon" value="<?php echo $tampil['3']?>">
            </p>
            <label class="control-label for="inputSuccess4"">
                Tanggal Lahir 
            </label>
                <input type="date" class="form-control" name="tgl_lahir" value="<?php echo $tampil['4']?>">
            </p>
            </label>
                <label>
                    Jenis Kelamin
                </label>
                <br>
                 <input type="radio" name="jk" value="Pria" id="lakilaki" required>
                    <label for="lakilaki">Pria</label>
                <input type="radio" name="jk" value="Wanita" id="perempuan" required>
                    <label for="perempuan">Wanita</label>
            </p>   
            <label class="control-label for="inputSuccess4"">
                Tanggal Reg 
            </label>
                <input type="date" class="form-control" name="reg" value="<?php echo $tampil['4']?>">
            </p>
            <label></label>
            </p>
             <input type="submit" name="edit" value="Edit" class=" btn btn-success">
            <a href="?page=pegawai_view"><button type="button" class="btn btn-warning">Cancel</button></a>
        </form>
         <?php
            }
            if (isset($_POST['edit'])) {
                $no=$_POST['no'];
                $nama=$_POST['nama'];
                $alamat=$_POST['alamat'];
                $tlp=$_POST['telepon'];
                $tgl=$_POST['tgl_lahir'];
                $jk=$_POST['jk'];
                $reg=$_POST['reg'];
                $query=mysql_query("UPDATE tb_pasien SET  kode_pas =  '$no', nama_pas =  '$nama', alamat_pas =  '$alamat',  telp_pas =  '$tlp', tanggal_lahir_pas =  '$tgl', jenis_kelamin_pas =  '$jk', tanggal_reg = '$reg' WHERE  kode_pas =  '$no'");
                if($query){
                    echo'<script>alert("Data Berhasil Di Update");
                    window.location.assign("?page=pasien_view");</script>';
                }else{
                    echo'<script>alert("Data Gagal Di Update");</script>';
                }
            }
            ?>
 </div>                                 
</div>