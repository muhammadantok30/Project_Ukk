<?php
  @session_start();
  include "../koneksi.php";
  if (@$_SESSION['asisten']) {
    
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="../../assets/ico/favicon.ico">

    <title>DOKTER || Antok</title>

    <!-- Bootstrap core CSS -->
    <link href="../dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../dist/css/dashboard.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">DOKTER POLIKLINIK</a>
        </div>
        <div class="navbar-collapse collapse" id="bs-example-navbar-collapse-1">
          <ul class="nav navbar-nav navbar-right">
          <div class="btn-group">
              <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                <span class="glyphicon glyphicon-user"> <?php echo $_SESSION['asisten'] ?></span>
                <span class="caret"></span>
              </button>
              <ul class="dropdown-menu">
                <li><a href="#"><span class="glyphicon glyphicon-wrench"></span> Setting</a></li>
                <li><a href="../inc/logout.php"><span class="glyphicon glyphicon-off"></span> Logout</a></li>
              </ul>
            </div>
            <li><a href="index.php"><span class="glyphicon glyphicon-dashboard"></span> Dashboard</a></li>
          </ul>
        </div>
      </div>
    </div>

    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
            <li class="active"><a href="#"><span class="glyphicon glyphicon-dashboard"></span> DASHBOARD</a></li>
            <li><a href="?page=resep_view"><span class="glyphicon glyphicon-list"></span> Data Reseps</a></li>
            <li><a href="?page=pemeriksaan_view"><span class="glyphicon glyphicon-list-alt"></span> Data Pemeriksaan</a></li>
          </ul>
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          <h1 class="page-header">Dashboard</h1>
        </div>
      </div>
    </div>
    <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
    <div class="table-responsive">
            <table class="table table-striped">
            	<?php 
            		switch (@$_GET['page']) {
            			case 'resep_view': include ("../model/resep/resep.php");break;
                                case'pemeriksaan_view':include("../model/pemeriksaan/pemeriksaan.php");break;
                                case'pemeriksaan_create':include("../model/pemeriksaan/pemeriksaan_create.php");break;
                                case'pemeriksaan_delete':include("../model/pemeriksaan/pemeriksaan_delete.php");break;
                                case'pemeriksaan_edit':include("../model/pemeriksaan/pemeriksaan_edit.php");break;
            			
            		}

            	?>

            </table>
            </div>
          </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="../dist/js/jquery.min.js"></script>
    <script src="../dist/js/bootstrap.min.js"></script>
    <script src="../assets/js/docs.min.js"></script>
  </body>
</html>

<?php 

  }else {
    header("Location: ../inc/login.php");
  }

?>